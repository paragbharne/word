<?php
namespace W3TC;

/**
 * Amazon CloudFront (S3 origin) CDN engine
 */

class CdnEngine_S3_Cf_S3 extends CdnEngine_S3_Cf {
	var $type = W3TC_CDN_CF_TYPE_S3;
}
